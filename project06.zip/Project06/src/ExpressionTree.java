/*
 * @Author Tyler Zysberg
 * Date: 12/5/16
 */
import java.util.Stack;
import osu.cse2123.TreeNode;

public class ExpressionTree {
	/**
	 * @param args
	 */

	public ExpressionTree(String x){
		TreeNode<String> p = buildTreeFromString(x);
	}

	 public static TreeNode<String> buildTreeFromString(String expr)
	 {
		 
		String[] array = expr.split("\\s+");
		boolean empty = false;
		
		Stack<TreeNode<String>> exprStack = new Stack<TreeNode<String>>();
		
		
		for(int i = 0; i < array.length; i++)
		{
			
			if(!Character.isDigit(array[i].charAt(0)))
			{
				TreeNode<String> operator = new TreeNode<String>(array[i]);
				operator.setRightChild(exprStack.pop());
				
				if(!exprStack.isEmpty())
				{
					operator.setLeftChild(exprStack.pop());
				}
				else
					empty = true;
					exprStack.push(operator);
			}
			
			else
			{
				TreeNode<String> operand = new TreeNode<String>(array[i]);
				exprStack.push(operand);
			}
		}
		if(exprStack.peek() == null || empty)
			return null;
		TreeNode<String> output = exprStack.pop();
		if(!exprStack.isEmpty()){
			return null;
			}
		else
			return output;
		}
	
		public static String toPostfixString(TreeNode<String> expr)
		{
			String display="";
			if(expr != null)
			{
				display = display + toPostfixString(expr.getLeftChild());
				display = display + toPostfixString(expr.getRightChild());
				display = display + expr.getData() + " ";
			}
			return display;
		}
		public static String toInfixString(TreeNode<String> expr){
			String display = "";
			if(expr != null){
				display = "(";
				display = display + toInfixString(expr.getLeftChild());
				display = display + expr.getData() + " ";
				display = display + toInfixString(expr.getRightChild());
				display =  display + ")";
			}
			return display;
		}
		public static String toPrefixString(TreeNode<String> expr){
			String display="";
			if(expr != null){
				display = display + expr.getData() + " ";
				display = display + toPrefixString(expr.getLeftChild());
				display = display + toPrefixString(expr.getRightChild());
			}
			return display;
		}
		public static int evaluate(TreeNode<String> expr)
		{
			int answer = 0;
			if (!Character.isDigit(expr.getData().charAt(0))){
				if (expr.getData().equals("+")){
					answer = evaluate(expr.getLeftChild()) + evaluate(expr.getRightChild());
					return answer;
				}
				else if (expr.getData().equals("-")){
					answer = evaluate(expr.getLeftChild())-evaluate(expr.getRightChild());
					return answer;
				}
				else if (expr.getData().equals("*")){
					answer = evaluate(expr.getLeftChild()) * evaluate(expr.getRightChild());;
					return answer;
				}
				else if (expr.getData().equals("%")){
					answer = evaluate(expr.getLeftChild()) % evaluate(expr.getRightChild());;
					return answer;
				}
				else {
					answer = evaluate(expr.getLeftChild())/evaluate(expr.getRightChild());
					return answer;
				}
			}
			else{
				return Integer.parseInt(expr.getData());
			}
		}
}






