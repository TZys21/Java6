/*
 * @Author Tyler Zysberg
 * Date 12/5/16
 * 
 * Did not have time to write up all the test cases because I have 3 finals this week and was out of town last week. 
 * I'm sorry, but I think the code is correct after runnning it many times.
 * 
 */
import java.util.Scanner;
import java.util.Stack;
import osu.cse2123.TreeNode;


public class project06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String expected ="";
		char first = ' ';
		char secondChoice;
		Scanner in = new Scanner(System.in);
		System.out.println("No expression in memory");
			System.out.println();
	
			
		while (first != 'Q' && first != 'q')
		{
			first = Questions();
			System.out.println();
			String user;
				
				if(first == 's' || first == 'S')
				{ 
					boolean set = false;
					while(set==false){
						secondChoice = otherQuestions();
					if(!expected.isEmpty())
						{
							
							if (secondChoice == 'p')
							{
								user = expected;
								TreeNode<String> post = (buildTreeFromString(user));
								user = toPostfixString(post);
								System.out.println(user + " = " + evaluate(post));
								set=true;
								System.out.println();
							}
							else if ( secondChoice == 'i')
							{ 
								user = expected;
								TreeNode<String> infix = (buildTreeFromString(user));
								
								user = toInfixString(infix);
								
								System.out.println(user.substring(1, user.length()-1) + " = " + evaluate(infix));
								set=true;
								System.out.println();
							}
							else
							{ 
								user = expected;
								TreeNode<String> pre = (buildTreeFromString(user));
								user = toPrefixString(pre);
								
								System.out.println(user + " = " + evaluate(pre));
								set=true;
								System.out.println();
							}
						}
						else
						{
							System.out.println("No expression in memory yet. ");
							set = true;
						}
					}
				}
				else if (first == 'e' || first == 'E')
				{ 
					boolean check = false;
					String equation = "";
					while(check==false)
					{
						System.out.print("Enter your expression in postfix notation: ");
						equation = in.nextLine() + " ";
						if (!equation.equals(toPostfixString(buildTreeFromString(equation))))
						{
							System.out.println("Error!  Expression not in postfix notation.");
							System.out.println();
						}
						else
							check= true;
					}
					
					expected = equation;
					System.out.println(expected + " = " + evaluate(buildTreeFromString(expected)));
					System.out.println();
				}
				else
				{ 
					System.out.println("GoodBye!");
				}
			}
		}
		
		
		
		 public static TreeNode<String> buildTreeFromString(String expr)
		 {
			 
			String[] array = expr.split("\\s+");
			boolean empty = false;
			
			Stack<TreeNode<String>> exprStack = new Stack<TreeNode<String>>();
			
			
			for(int i = 0; i < array.length; i++)
			{
				
				if(!Character.isDigit(array[i].charAt(0)))
				{
					TreeNode<String> operator = new TreeNode<String>(array[i]);
					operator.setRightChild(exprStack.pop());
					
					if(!exprStack.isEmpty())
					{
						operator.setLeftChild(exprStack.pop());
					}
					else
						empty = true;
						exprStack.push(operator);
				}
				
				else
				{
					TreeNode<String> operand = new TreeNode<String>(array[i]);
					exprStack.push(operand);
				}
			}
			if(exprStack.peek() == null || empty)
				{
				return null;
				}
			TreeNode<String> output = exprStack.pop();
			if(!exprStack.isEmpty())
			{
				return null;
				}
			else
				return output;
			}
		
			public static String toPostfixString(TreeNode<String> expr)
			{
				String display="";
				if(expr != null)
				{
					display = display + toPostfixString(expr.getLeftChild());
					display = display + toPostfixString(expr.getRightChild());
					display = display + expr.getData() + " ";
				}
				return display;
			}
			public static String toInfixString(TreeNode<String> expr){
				String output = "";
				if(expr != null)
				{
					output = "(";
					output = output + toInfixString(expr.getLeftChild());
					output = output + expr.getData() + " ";
					output = output + toInfixString(expr.getRightChild());
					output =  output + ")";
				}
				return output;
			}
			public static String toPrefixString(TreeNode<String> expr){
				String output="";
				if(expr != null)
				{
					output = output + expr.getData() + " ";
					output = output + toPrefixString(expr.getLeftChild());
					output = output + toPrefixString(expr.getRightChild());
				}
				return output;
			}
			public static int evaluate(TreeNode<String> expr)
			{
				int answer = 0;
				if (!Character.isDigit(expr.getData().charAt(0)))
				{
					if (expr.getData().equals("+"))
					{
						answer = evaluate(expr.getLeftChild()) + evaluate(expr.getRightChild());
						return answer;
					}
					else if (expr.getData().equals("-"))
					{
						answer = evaluate(expr.getLeftChild())-evaluate(expr.getRightChild());
						return answer;
					}
					else if (expr.getData().equals("*"))
					{
						answer = evaluate(expr.getLeftChild()) * evaluate(expr.getRightChild());;
						return answer;
					}
					else if (expr.getData().equals("%"))
					{
						answer = evaluate(expr.getLeftChild()) % evaluate(expr.getRightChild());;
						return answer;
					}
					else 
					{
						answer = evaluate(expr.getLeftChild())/evaluate(expr.getRightChild());
						return answer;
					}
				}
				else
				{
					return Integer.parseInt(expr.getData());
				}
			}
		public static char Questions()
		{
			Scanner in = new Scanner(System.in);
			System.out.println("Enter your choice: ");
			System.out.println("[S]et the display format");
			System.out.println("[E]nter a new expression");
			System.out.println("[Q]uit");
			System.out.print(">");
			String x = in.next();
			while ((x.length()!=1)||(!(x.charAt(0)=='s'||x.charAt(0)=='e'||x.charAt(0)=='q'||x.charAt(0)=='S'||x.charAt(0)=='E'||x.charAt(0)=='Q')))
			{
				System.out.println("ERROR! You must enter one of [E], [S], or [Q]!");
				System.out.println("Enter your choice: ");
				System.out.println("[S]et the display format");
				System.out.println("[E]nter a new expression");
				System.out.println("[Q]uit");
				System.out.print(">");
				x = in.next();
			}
			char t = x.charAt(0);
			return t;
			
		}
			public static char otherQuestions()
			{
				Scanner in = new Scanner(System.in);
				System.out.println("Enter your preferred output display:");
				System.out.println("[P]ostfix");
				System.out.println("[I]nfix");
				System.out.println("p[R]efix");
				System.out.print(">");
				String x = in.next();
				while ((x.length()!=1)||(!(x.charAt(0)=='p'||x.charAt(0)=='i'||x.charAt(0)=='r'||x.charAt(0)=='P'||x.charAt(0)=='I'||x.charAt(0)=='R')))
				{
					System.out.println("INVALID!");
					System.out.println("Enter your preferred output display:");
					System.out.println("[P]ostfix");
					System.out.println("[I]nfix");
					System.out.println("p[R]efix");
					System.out.print(">");
					x = in.next();
				}
				char t = x.charAt(0);
				return t;
				
			}


	}


